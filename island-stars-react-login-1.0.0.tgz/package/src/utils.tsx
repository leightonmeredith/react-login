export function login({
  email,
  password,
}: {
  email: string;
  password: string;
}) {
  const delay = (0.7 + Math.random() * 2) * 1000;
  return new Promise<void>((resolve, reject) => {
    setTimeout(function () {
      if (password === "pass123" && !!email) {
        resolve();
      } else {
        reject(new Error("Invalid email or password"));
      }
    }, delay);
  });
}
